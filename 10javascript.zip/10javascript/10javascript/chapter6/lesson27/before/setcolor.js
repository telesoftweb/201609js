window.addEventListener('load', 
	function(event){
		setBoxColor();
	}
, false);
//色設定
function setBoxColor(){
}
